export const allNews = [
  {
    id: 1,
    image: "https://via.placeholder.com/575x480",
    title: '10 things you must know before trading in cryptocurrency',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  },
  {
    id: 2,
    image: "https://via.placeholder.com/575x480",
    title: 'Getting started with cryptocurrency - what is blockchain',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  },
  {
    id: 3,
    image: "https://via.placeholder.com/575x480",
    title: 'Is cryptocurrency investment a trap or opportunity?',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  }
];
export const bitCoinNews = [
  {
    id: 3,
    image: "https://via.placeholder.com/575x480",
    title: 'Is cryptocurrency investment a trap or opportunity?',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  },
  {
    id: 1,
    image: "https://via.placeholder.com/575x480",
    title: '10 things you must know before trading in cryptocurrency',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  },
  {
    id: 2,
    image: "https://via.placeholder.com/575x480",
    title: 'Getting started with cryptocurrency - what is blockchain',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  },

];
export const rippleNews = [

  {
    id: 2,
    image: "https://via.placeholder.com/575x480",
    title: 'Getting started with cryptocurrency - what is blockchain',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  },
  {
    id: 1,
    image: "https://via.placeholder.com/575x480",
    title: 'Is cryptocurrency investment a trap or opportunity?',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  },
  {
    id: 1,
    image: "https://via.placeholder.com/575x480",
    title: '10 things you must know before trading in cryptocurrency',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  },
];
export const lightCoinNews = [
  {
    id: 1,
    image: "https://via.placeholder.com/575x480",
    title: '10 things you must know before trading in cryptocurrency',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  },
  {
    id: 2,
    image: "https://via.placeholder.com/575x480",
    title: 'Getting started with cryptocurrency - what is blockchain',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  },
  {
    id: 3,
    image: "https://via.placeholder.com/575x480",
    title: 'Is cryptocurrency investment a trap or opportunity?',
    subTitle: 'Cras tincidunt sit amet massa at accumsan. Mauris tincidunt tincidunt est, et pulvinar\n' +
    'felis pharetra in vestibulum sed.',
    desc: 'BTC, Crypto, Trading, Tips, Cryptocurrency',
  }
];
