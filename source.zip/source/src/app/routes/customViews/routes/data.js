export const data = [

  {
    name: 'Domnic Harris',
    designation: 'Android Developer',
    image: "https://via.placeholder.com/150x150",
    description: "All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet"
  },
  {
    name: 'Garry Sobars',
    designation: 'React Developer',
    image: "https://via.placeholder.com/150x150",
    description: "It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable."
  },
  {
    name: 'Stella Johnson',
    designation: 'Designer',
    image: "https://via.placeholder.com/150x150",
    description: "The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc."
  }, {
    name: 'John Smith',
    designation: 'BDM',
    image: "https://via.placeholder.com/150x150",
    description: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum."
  },
  {
    name: 'Alex Dolgove',
    designation: 'Actor',
    image: "https://via.placeholder.com/150x150",
    description: "Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' "
  },
  {
    name: 'Domnic Brown',
    designation: 'Singer',
    image: "https://via.placeholder.com/150x150",
    description: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable."
  },
];
