import React, {Component} from 'react';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import PhoneIcon from '@material-ui/icons/Phone';
import FavoriteIcon from '@material-ui/icons/Favorite';
import PersonPinIcon from '@material-ui/icons/PersonPin';

export default class IconTabs extends Component {
  state = {
    value: 0,
  };

  handleChange = (event, value) => {
    this.setState({value});
  };

  render() {
    return (
      <Paper>
        <Tabs
          value={this.state.value}
          onChange={this.handleChange}
          variant="fullWidth"
          indicatorColor="primary"
          textColor="primary"
          scrollButtons="on"
        >
          <Tab className="tab" icon={<PhoneIcon/>}/>
          <Tab className="tab" icon={<FavoriteIcon/>}/>
          <Tab className="tab" icon={<PersonPinIcon/>}/>
        </Tabs>
      </Paper>
    );
  }
}