const style = {
  top: 0,
  left: 350,
  lineHeight: '24px'
};
export default style;